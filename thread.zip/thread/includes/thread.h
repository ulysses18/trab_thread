void get_file_name(char *pnum_times[100]);
void read_file(char *pnum_times[100]);