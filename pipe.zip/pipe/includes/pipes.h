void client(int, int);
void server(int, int);